package com.example.beat_sheet;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

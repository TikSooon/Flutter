class Projects {

  String projectName;
  String projectCreatedDate;
  bool isSelected = false;

  Projects(this.projectName, this.projectCreatedDate, this.isSelected);

}

